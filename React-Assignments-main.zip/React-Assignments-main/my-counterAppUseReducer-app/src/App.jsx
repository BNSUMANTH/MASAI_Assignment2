import { useState } from 'react'

import './App.css'
import { CounterApp } from './components/CounterApp'

function App() {
  
  return (
    <>
        <CounterApp/>  
    </>
  )
}

export default App
