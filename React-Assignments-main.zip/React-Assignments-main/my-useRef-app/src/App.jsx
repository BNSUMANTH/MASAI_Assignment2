
import './App.css'
import { FocusInput } from './components/InputText'

function App() {

  return (
    <>
      <FocusInput/>
    </>
  )
}

export default App
