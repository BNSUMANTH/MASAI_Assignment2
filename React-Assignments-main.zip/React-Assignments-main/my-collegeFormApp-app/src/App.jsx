import { useState } from 'react'

import './App.css'
import { CollegeFormApp } from './components/collegeFormApp'

function App() {
  

  return (
    <>
      <CollegeFormApp/>
    </>
  )
}

export default App
