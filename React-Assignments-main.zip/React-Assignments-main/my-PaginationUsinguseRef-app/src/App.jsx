import { useState } from 'react'

import './App.css'
import Pagination from './components/Pagination'

function App() {
  

  return (
    <>
        <Pagination/>
    </>
  )
}

export default App
