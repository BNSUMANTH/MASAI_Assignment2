import React from "react";

function Concact() {
  return (
    <div>
      <h1>Concact</h1>
    </div>
  );
}
export { Concact };
