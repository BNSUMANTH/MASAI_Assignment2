import React from "react";

 function Error(){
    return (
        <div>
            <h2>Error , 404 Found..</h2>
        </div>
    )
}
export {Error}