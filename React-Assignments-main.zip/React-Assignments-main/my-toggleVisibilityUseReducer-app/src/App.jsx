import { useState } from 'react'

import './App.css'
import { ToggleData } from './components/ToggleData'

function App() {
  

  return (
    <>
      <ToggleData/>
    </>
  )
}

export default App
