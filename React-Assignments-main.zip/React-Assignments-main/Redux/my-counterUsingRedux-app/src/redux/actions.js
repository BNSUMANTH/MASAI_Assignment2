 function increment(){
    return ({type:"incre"})
}
 function decrement(){
    return ({type:"decre"})
}
export {decrement,increment}