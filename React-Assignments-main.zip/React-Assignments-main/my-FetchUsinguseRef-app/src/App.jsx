import { useState } from 'react'

import './App.css'
import { FetchData } from './components/FetchData'

function App() {
  
  return (
    <>
      <FetchData/>
    </>
  )
}

export default App
