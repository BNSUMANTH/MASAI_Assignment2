import { useState } from 'react'

import './App.css'
import { ToggleApp } from './components/ToggleTheme'

function App() {
  

  return (
    <>
      <ToggleApp/>
    </>
  )
}

export default App
